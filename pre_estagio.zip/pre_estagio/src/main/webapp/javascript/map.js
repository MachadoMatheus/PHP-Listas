let map, selectedElement;
let coordinatesMegatecnologia = {lat: -29.687384, lng: -53.808217};
let dotsQtyElement = document.getElementById("dotsQty"),
    colorElement = document.getElementById("color"),
    opacityElement = document.getElementById("opacity"),
    sizeElement = document.getElementById("size"),
    coordinatesContainer = document.getElementById("coordinates");
const SIMPLE_CIRCLE = "M-0.5,0a0.5,0.5,0,1,0,1,0a0.5,0.5,0,1,0,-1,0";

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 15,
        center: coordinatesMegatecnologia,
        mapTypeId: 'roadmap',
        mapTypeControl: false,
        streetViewControl: false
    });

    startMapListeners();
    requestOverlayElements(drawDbElements);
}

function requestOverlayElements(callbackFunction) {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            callbackFunction(JSON.parse(this.response));
        }
    };
    xhttp.open("GET", "getOverlayElements", true);
    xhttp.send();
}

function sendOverlayElement(overlayElement) {
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", "setOverlayElement", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(overlayElement));
}

function removeOverlayElement(overlayElement) {
    let xhttp = new XMLHttpRequest();
    xhttp.open("POST", "deleteOverlayElement", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify(overlayElement));
}

function addMarker(overlayElement) {
    let image = {
        strokeWeight: 0,
        fillColor: overlayElement.color,
        fillOpacity: overlayElement.opacity,
        scale: overlayElement.size,
        path: SIMPLE_CIRCLE,
    };

    let options = {
        draggable: true,
        map: map,
        icon: image,
        position: overlayElement.coordinates[0]
    };

    return new google.maps.Marker(options);
}

function addPolyline(overlayElement) {
    let options = {
        strokeColor: overlayElement.color,
        strokeOpacity: overlayElement.opacity,
        strokeWeight: overlayElement.size,
        draggable: true,
        map: map,
        path: overlayElement.coordinates
    };

    return new google.maps.Polyline(options);
}

function addElement(overlayElement) {
    let element;
    if (overlayElement.coordinates.length > 1) {
        element = addPolyline(overlayElement);
    } else {
        element = addMarker(overlayElement);
    }

    element.addListener("dblclick", handleElementDoubleClick);
    return element;
}

function addElements(overlayElements) {
    let elementsInserted = [];
    for (let i = 0; i < overlayElements.length; i++) {
        elementsInserted.push(addElement(overlayElements[i]));
    }
    return elementsInserted;
}

function removeElement(element) {
    element.setMap(null);
    element = undefined;
}

function lockElements(elements) {
    for (let element of elements) {
        element.setDraggable(false);
    }
}

function modifyElementStyleProperty(element, nameIfMarker, nameIfPolyline, value) {
    if (isMarker(element)) {
        let image = element.getIcon();
        image[nameIfMarker] = value;
        element.setIcon(image);
    } else {
        let options = {};
        options[nameIfPolyline] = value;
        element.setOptions(options);
    }
}

function getRandomDouble(min, max) {
    return Math.random() * (max - min) + min;
}

function getRandomColor() {
    let hexNumbers = "0123456789ABCDEF";
    let color = "#";
    for (let i = 0; i < 6; i++) {
        color += hexNumbers[Math.floor(Math.random() * 16)];
    }

    return color;
}

function getRandomLatLngInsideBounds() {
    let bounds = getPercentageOfViewArea(0.8);
    let minLat = bounds.getSouthWest().lat(), maxLat = bounds.getNorthEast().lat(),
        minLng = bounds.getSouthWest().lng(), maxLng = bounds.getNorthEast().lng();

    return new google.maps.LatLng(
        getRandomDouble(minLat, maxLat),
        getRandomDouble(minLng, maxLng)
    );
}

function getMultipleRandomLatLngInsideBounds(amount) {
    let latLngArray = [];
    for (let i = 0; i < amount; i++) {
        latLngArray.push(getRandomLatLngInsideBounds());
    }
    return latLngArray;
}

function getPercentageOfViewArea(percentage) {
    let bounds = map.getBounds(), ne = bounds.getNorthEast(), sw = bounds.getSouthWest();
    let minLat = sw.lat(), maxLat = ne.lat(), minLng = sw.lng(), maxLng = ne.lng();
    let verticalSize = maxLat - minLat, horizontalSize = maxLng - minLng;

    let verticalModifier = (verticalSize * (1 - percentage)) / 2;
    let rightModifier = (horizontalSize * (1 - percentage)) / 2;
    let leftModifier = rightModifier + (horizontalSize * (1 - 0.6));

    minLat += verticalModifier;
    maxLat -= verticalModifier;
    minLng += leftModifier;
    maxLng -= rightModifier;

    return new google.maps.LatLngBounds(
        {lat: minLat, lng: minLng},
        {lat: maxLat, lng: maxLng}
    );
}

function isPolyline(object) {
    return object instanceof google.maps.Polyline;
}

function isMarker(object) {
    return object instanceof google.maps.Marker;
}

function sortCoordinates(elements) {
    for (let element of elements) {
        let orderedCoordinates = [];
        for (let coordinate of element.coordinates) {
            orderedCoordinates[coordinate.position] = coordinate;
        }
        element.coordinates = orderedCoordinates;
    }
}

function makeEditableIfPolyline(element) {
    if (isPolyline(element)) {
        let listeners = [];
        listeners.push(
            element.addListener("rightclick", handlePolylineRightClick),
            element.addListener("dragstart", handlePolylineDragStart),
            element.addListener("dragend", handlePolylineDragEnd),
            element.getPath().addListener("insert_at", handlePolylineInsertAt),
            element.getPath().addListener("set_at", handlePolylineSetAt)
        );
        element.setEditable(true);
        element.listeners = listeners;
        element.isStopped = true;
    }
}

function makeUneditableIfPolyline(element) {
    if (isPolyline(element)) {
        for (let listener of element.listeners) {
            listener.remove();
        }
        element.setEditable(false);
        element.isStopped = true;
    }
}

function handlePolylineDragStart() {
    this.isStopped = false;
}

function handlePolylineDragEnd() {
    this.isStopped = true;
}

function showInfoWindowWithCoordinates() {
    let coordinates = getElementCoordinates(this);
    let latLngInfo = "<table class='infoWindow'><tr><th>Latitude</th><th>Longitude</th></tr>";
    for (let latLng of coordinates) {
        latLngInfo += "<tr><td>" + latLng.lat() + "</td><td>" + latLng.lng() + "</td></tr>";
    }
    latLngInfo += "</table>";
    let infoWindow = new google.maps.InfoWindow({content: latLngInfo});
    infoWindow.setPosition(coordinates[0]);
    infoWindow.open(map);
}

function handleElementDoubleClick(event) {
    showInfoWindowWithCoordinates.apply(this);
    event.stop();
}

function getElementCoordinates(element) {
    if (isMarker(element)) {
        return [element.getPosition()];
    } else {
        return element.getPath().getArray();
    }

}

function avoidInsertAtBug(insertedIndex) {
    selectedElement.getPath().removeAt(insertedIndex);
    makeUneditableIfPolyline(selectedElement);
    makeEditableIfPolyline(selectedElement);
}

/************************************************************************/

function startFormListeners() {
    dotsQtyElement.addEventListener("change", handleDotsQtyChange);
    colorElement.addEventListener("change", modifySelectedElementColor);
    sizeElement.addEventListener("change", modifySelectedElementSize);
    opacityElement.addEventListener("change", modifySelectedElementOpacity);

    let valueModifiers = document.getElementsByClassName("value-modifier");
    for (let element of valueModifiers) {
        element.addEventListener("click", modifyValueOfOwner);
    }
}

function modifyValueOfOwner() {
    let owner = document.getElementById(this.id.substr(4));
    switch (this.id[0]) {
        case "d":
            owner.stepDown(1);
            break;
        case "i":
            owner.stepUp(1);
            break;
    }
    owner.dispatchEvent(new Event('change'));
}

function createAndAppendCoordinate(index) {
    let coordinateContainer = document.createElement("div");
    setAttributes(coordinateContainer, {id: "coordinateContainer" + index, class: "coordinateContainer"});
    let fullName = ["latitude", "longitude"];
    let abbr = ["lat", "lng"];

    let label = document.createElement("div");
    label.setAttribute("class", "lat-lng-label");
    label.innerText = (index + 1) + "º ";
    coordinateContainer.appendChild(label);

    for (let i = 0; i < 2; i++) {
        let input = document.createElement("input");
        setAttributes(input, {
            class: fullName[i],
            name: "coordinates[" + index + "]." + abbr[i],
            id: "coordinates" + index + "." + abbr[i],
            type: "number",
            step: "any",
            required: "true"
        });
        input.addEventListener("change", handleLatLngChange);
        coordinateContainer.appendChild(input);
    }

    coordinatesContainer.appendChild(coordinateContainer);
}

function setAttributes(element, attributes) {
    for (let property in attributes) {
        if (attributes.hasOwnProperty(property))
            element.setAttribute(property, attributes[property]);
    }
}

function handleLatLngChange() {
    let index = Number.parseInt(this.id[11]);
    if (isMarker(selectedElement)) {
        selectedElement.setPosition(getLatLngInputValue(index), index);
    } else {
        selectedElement.getPath().setAt(index, getLatLngInputValue(index));
    }
}

function setLatLngInputValue(latLng, index) {
    document.getElementById("coordinates" + index + ".lat").value = latLng.lat();
    document.getElementById("coordinates" + index + ".lng").value = latLng.lng();
}

function getLatLngInputValue(index) {
    return new google.maps.LatLng(
        document.getElementById("coordinates" + index + ".lat").valueAsNumber,
        document.getElementById("coordinates" + index + ".lng").valueAsNumber
    );
}

function getAllLatLngInputValues() {
    let latLngArray = [];
    for (let i = 0; i < coordinatesContainer.childElementCount; i++) {
        latLngArray.push(getLatLngInputValue(i));
    }
    return latLngArray;
}

function isInsideOwnLimits(element) {
    return element.max >= element.valueAsNumber && element.min <= element.valueAsNumber;
}

function modifySelectedElementColor() {
    modifyElementStyleProperty(selectedElement, "fillColor",
        "strokeColor", colorElement.value);
}

function modifySelectedElementSize() {
    if (isInsideOwnLimits(sizeElement)) {
        modifyElementStyleProperty(selectedElement, "scale",
            "strokeWeight", sizeElement.valueAsNumber);
    } else {
        sizeElement.valueAsNumber = 16;
    }
}

function modifySelectedElementOpacity() {
    if (isInsideOwnLimits(opacityElement)) {
        modifyElementStyleProperty(selectedElement, "fillOpacity",
            "strokeOpacity", opacityElement.valueAsNumber);
    } else {
        opacityElement.valueAsNumber = 0.8;
    }
}

function commonDotsQtyChangeHandler() {
    if (!isInsideOwnLimits(dotsQtyElement)) {
        dotsQtyElement.valueAsNumber = 9;
    }
    let dotsQty = dotsQtyElement.valueAsNumber,
        coordinates = coordinatesContainer.childNodes;
    if (dotsQty > coordinates.length) {
        addPointsToSelectedElementAndInputs(
            getMultipleRandomLatLngInsideBounds(dotsQty - coordinates.length)
        );
    } else if (dotsQty < coordinates.length) {
        let indexesToRemove = [];
        for (let i = coordinates.length - 1; i >= dotsQty; i--) {
            indexesToRemove.push(i);
        }
        removePointsFromSelectedElementAndInputs(indexesToRemove);
    }
}

function commonInsertAtHandler(insertedIndex) {
    if (selectedElement.isStopped) {
        let path = selectedElement.getPath();
        if (path.getLength() > 9) {
            avoidInsertAtBug(insertedIndex);
        } else {
            let lastIndex = coordinatesContainer.childElementCount;
            createAndAppendCoordinate(lastIndex);
            let i = 0;
            for (let latLng of path.getArray()) {
                setLatLngInputValue(latLng, i);
                i++;
            }
            dotsQtyElement.stepUp(1);
        }
    }
}

function commonSetAtHandler(index) {
    if (selectedElement.isStopped) {
        let path = selectedElement.getPath();
        setLatLngInputValue(path.getAt(index), index);
    }
}

function commonDragEnd(element) {
    if (isMarker(element)) {
        setLatLngInputValue(element.getPosition(), 0);
    } else {
        let i = 0;
        for (let latLng of element.getPath().getArray()) {
            setLatLngInputValue(latLng, i);
            i++;
        }
    }
}

function parseLatLngToLatLngLiteral(coordinates) {
    let parsedCoordinates = [];
    for (let i = 0; i < coordinates.length; i++) {
        parsedCoordinates[i] = coordinates[i].toJSON();
    }
    return parsedCoordinates;
}

function addPointsToSelectedElementAndInputs(coordinates) {
    addPointsToInputs(coordinates);
    addPointsToSelectedElement(coordinates);
}

function addPointsToInputs(coordinates) {
    for (let coordinate of coordinates) {
        let newPointIndex = coordinatesContainer.childElementCount;
        createAndAppendCoordinate(newPointIndex);
        setLatLngInputValue(coordinate, newPointIndex);
    }
}

function removePointsFromSelectedElementAndInputs(indexes) {
    removePointsFromInputs(indexes);
    removePointsFromSelectedElement(indexes);
}

function removePointsFromInputs(indexes) {
    for (let index of indexes) {
        coordinatesContainer.removeChild(coordinatesContainer.childNodes[index]);
    }

    let i = 0;
    for (let child of coordinatesContainer.childNodes) {
        child.getElementsByClassName("lat-lng-label")[0].innerHTML = (i + 1) + "º";
        setAttributes(child.getElementsByClassName("latitude")[0], {
            id: "coordinates" + i + ".lat",
            name: "coordinates[" + i + "].lat"
        });
        setAttributes(child.getElementsByClassName("longitude")[0], {
            id: "coordinates" + i + ".lng",
            name: "coordinates[" + i + "].lng"
        });
        child.id = "coordinateContainer" + i;
        i++;
    }
}

function removePointsFromSelectedElement(indexes) {
    let path = selectedElement.getPath();
    for (let index of indexes) {
        path.removeAt(index);
    }

    if (path.getLength() === 1) {
        let marker = addElement(parseElementToOverlayElement(selectedElement));
        replaceSelectedElement(marker);
    }
}

function addPointsToSelectedElement(coordinates) {
    let polyline = parseElementToOverlayElement(selectedElement);
    polyline.coordinates = polyline.coordinates.concat(parseLatLngToLatLngLiteral(coordinates));
    polyline = addElement(polyline);

    replaceSelectedElement(polyline);
}

function parseElementToOverlayElement(element) {
    let overlayElement;
    if (isMarker(element)) {
        overlayElement = parseMarkerToOverlayElement(element);
    } else {
        overlayElement = parsePolylineToOverlayElement(element);
    }
    return overlayElement;
}

function parseMarkerToOverlayElement(marker) {
    let image = marker.getIcon();
    return {
        color: image.fillColor,
        opacity: image.fillOpacity,
        size: image.scale,
        coordinates: [marker.getPosition().toJSON()]
    };
}

function parsePolylineToOverlayElement(polyline) {
    let coordinates = [];

    let i = 0;
    for (let coordinate of polyline.getPath().getArray()) {
        coordinates[i] = coordinate.toJSON();
        i++;
    }

    return {
        color: polyline.strokeColor,
        opacity: polyline.strokeOpacity,
        size: polyline.strokeWeight,
        coordinates: coordinates
    };
}