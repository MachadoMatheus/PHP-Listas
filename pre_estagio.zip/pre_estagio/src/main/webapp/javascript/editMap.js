let elementsMap = {};
changeSubmit();

function startMapListeners() {
    google.maps.event.addListener(map, "click", handleMapClick);
    google.maps.event.addListener(map, "rightclick", handleMapRightClick);
    google.maps.event.addListenerOnce(map, "bounds_changed", handleFirstBoundChange);
}

function changeSubmit() {
    let submit = document.getElementById("submit");
    submit.value = "Remover";
    submit.type = "button";
    submit.addEventListener("click", handleRemoveClick);
}

function handleRemoveClick() {
    if (selectedElement != null) {
        deleteElement(selectedElement);
        removeElement(selectedElement);
    }
}

function handleFirstBoundChange() {
    initCoordinateFields();
    startFormListeners();
    document.getElementsByClassName("overlayArea")[0].style.visibility = "visible";
    document.getElementsByClassName("overlayArea")[0].style.opacity = "1";
}

function initCoordinateFields() {
    dotsQtyElement.valueAsNumber = 1;
    createAndAppendCoordinate(0);
    setLatLngInputValue(new google.maps.LatLng(0, 0), 0);
}

function drawDbElements(elements) {
    sortCoordinates(elements);
    let elementsInserted = addElements(elements);
    for (let i = 0; i < elements.length; i++) {
        let id = elements[i].id;
        let elementInserted = elementsInserted[i];
        addListeners(elementInserted);
        addToMap(elementInserted, id);
    }
}

function handlePolylineRightClick(event) {
    if (Number.isInteger(event.vertex)) {
        dotsQtyElement.stepDown(1);
        removePointsFromSelectedElementAndInputs([event.vertex]);
        sendElement(selectedElement);
    }
}

function handlePolylineInsertAt(insertedIndex) {
    commonInsertAtHandler(insertedIndex);
    handlePathEvent();
}

function handlePolylineSetAt(index) {
    commonSetAtHandler(index);
    handlePathEvent();
}

function handleMapClick(event) {
    if (selectedElement != null &&
        dotsQtyElement.valueAsNumber < dotsQtyElement.max &&
        dotsQtyElement.valueAsNumber >= dotsQtyElement.min) {

        dotsQtyElement.stepUp(1);
        addPointsToSelectedElementAndInputs([event.latLng]);
        sendElement(selectedElement);
    }
}

function handleDragEnd() {
    if (selectedElement !== this) {
        handleElementClick.apply(this);
    }
    commonDragEnd(this);
    sendElement(this);
}

function handlePathEvent() {
    if (selectedElement.isStopped) {
        sendElement(selectedElement);
    }
}

function handleElementClick() {
    makeUneditableIfPolyline(selectedElement);
    selectedElement = this;
    makeEditableIfPolyline(selectedElement);
    document.getElementById("formContainer").disabled = false;
    setInputValuesByElement(selectedElement);
}

function handleMapRightClick() {
    document.getElementById("formContainer").disabled = true;
    makeUneditableIfPolyline(selectedElement);
    clearInputValues();
    selectedElement = null;
}

function handleDotsQtyChange() {
    commonDotsQtyChangeHandler();
    sendElement(selectedElement);
}

function addListeners(element) {
    element.addListener("dragend", handleDragEnd);
    element.addListener("click", handleElementClick);
}

function addToMap(element, id) {
    elementsMap[id] = element;
}

function sendElement(element) {
    let overlayElement = parseElementToOverlayElement(element);
    overlayElement.id = getKeyByValue(element);
    setPositionsOfCoordinates(overlayElement);
    sendOverlayElement(overlayElement);
}

function deleteElement(element) {
    let overlayElement = parseElementToOverlayElement(element);
    overlayElement.id = getKeyByValue(element);
    setPositionsOfCoordinates(overlayElement);
    document.getElementById("formContainer").disabled = true;
    clearInputValues();
    removeOverlayElement(overlayElement);
}

function getKeyByValue(value) {
    return Object.keys(elementsMap).find(key => elementsMap[key] === value);
}

function setPositionsOfCoordinates(overlayElement) {
    for (let i = 0; i < overlayElement.coordinates.length; i++) {
        overlayElement.coordinates[i].position = i;
    }
}

function replaceSelectedElement(newElement) {
    addToMap(newElement, getKeyByValue(selectedElement));
    removeElement(selectedElement);
    selectedElement = newElement;
    addListeners(selectedElement);
    makeEditableIfPolyline(selectedElement);
}


function setInputValuesByElement(element) {
    let overlayElement = parseElementToOverlayElement(element);
    colorElement.value = overlayElement.color;
    opacityElement.valueAsNumber = overlayElement.opacity;
    sizeElement.valueAsNumber = overlayElement.size;
    setCoordinatesInputs(getElementCoordinates(element));
}

function clearInputValues() {
    colorElement.value = "#000000";
    opacityElement.valueAsNumber = 0.8;
    sizeElement.valueAsNumber = 16;
    unsetCoordinatesInputs();
}

function setCoordinatesInputs(coordinates) {
    let coordinatesInput = coordinatesContainer.childNodes;

    let i = 0;
    while (i < getLowestValue(coordinates.length, coordinatesInput.length)) {
        setLatLngInputValue(coordinates[i], i);
        i++;
    }

    if (coordinates.length > coordinatesInput.length) {
        let coordinatesToAdd = coordinates.slice(coordinatesInput.length);
        addPointsToInputs(coordinatesToAdd);
    } else if (coordinates.length < coordinatesInput.length) {
        let indexesToRemove = [];
        for (let i = coordinatesInput.length - 1; i >= coordinates.length; i--) {
            indexesToRemove.push(i);
        }
        removePointsFromInputs(indexesToRemove);
    }

    dotsQtyElement.valueAsNumber = coordinates.length;
}

function unsetCoordinatesInputs() {
    setCoordinatesInputs([new google.maps.LatLng(0, 0)]);
}

function getLowestValue(a, b) {
    if (a > b) {
        return b;
    } else {
        return a;
    }
}

function addPointsToSelectedElement(coordinates) {
    let polyline = parseElementToOverlayElement(selectedElement);
    polyline.coordinates = polyline.coordinates.concat(parseLatLngToLatLngLiteral(coordinates));
    polyline = addElement(polyline);

    replaceSelectedElement(polyline);
}
