function startMapListeners() {
    google.maps.event.addListener(map, "click", handleMapClick);
    google.maps.event.addListenerOnce(map, "bounds_changed", handleFirstBoundChange);
}

function handleFirstBoundChange() {
    colorElement.value = getRandomColor();
    initCoordinateFields();
    startFormListeners();

    setSelectedElement(addElement(getElementOptionsFromInputs()));
    showInfoWindowWithCoordinates.apply(selectedElement);
    document.getElementById("formContainer").disabled = false;
    document.getElementsByClassName("overlayArea")[0].style.visibility = "visible";
    document.getElementsByClassName("overlayArea")[0].style.opacity = "1";
}

function initCoordinateFields() {
    dotsQtyElement.valueAsNumber = 1;
    createAndAppendCoordinate(0);
    setLatLngInputValue(getRandomLatLngInsideBounds(), 0);
}

function drawDbElements(elements) {
    sortCoordinates(elements);
    elements = addElements(elements);
    lockElements(elements);
}

function handlePolylineRightClick(event) {
    if (Number.isInteger(event.vertex)) {
        dotsQtyElement.stepDown(1);
        removePointsFromSelectedElementAndInputs([event.vertex]);
    }
}

function handlePolylineInsertAt(insertedIndex) {
    commonInsertAtHandler(insertedIndex)
}

function handlePolylineSetAt(index) {
    commonSetAtHandler(index);
}

function handleMapClick(event) {
    if (dotsQtyElement.valueAsNumber < dotsQtyElement.max && dotsQtyElement.valueAsNumber >= dotsQtyElement.min) {
        dotsQtyElement.stepUp(1);
        addPointsToSelectedElementAndInputs([event.latLng]);
    }
}

function handleDragEnd() {
    commonDragEnd(selectedElement);
}

function handleDotsQtyChange() {
    commonDotsQtyChangeHandler();
}

function setSelectedElement(newElement) {
    selectedElement = newElement;
    makeEditableIfPolyline(selectedElement);
    addListenersToSelectedElement();
}

function addListenersToSelectedElement() {
    selectedElement.addListener("dragend", handleDragEnd);
}

function replaceSelectedElement(newElement) {
    removeElement(selectedElement);
    setSelectedElement(newElement)
}

function getElementOptionsFromInputs() {
    return {
        color: colorElement.value,
        opacity: opacityElement.valueAsNumber,
        size: sizeElement.valueAsNumber,
        coordinates: getAllLatLngInputValues()
    }
}