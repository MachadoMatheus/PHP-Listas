package br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.entities;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

import static javax.persistence.CascadeType.ALL;

@Entity
@Table(name = "overlay_element")
public class OverlayElement {
    private Integer id;
    private String color;
    private double opacity, size;
    private List<Coordinate> coordinates;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "color")
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Basic
    @Column(name = "opacity")
    public double getOpacity() {
        return opacity;
    }

    public void setOpacity(double opacity) {
        this.opacity = opacity;
    }

    @Basic
    @Column(name = "size")
    public double getSize() {
        return size;
    }

    @OneToMany(targetEntity = Coordinate.class, cascade = ALL, mappedBy = "overlayElement", fetch = FetchType.EAGER)
    public List<Coordinate> getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(List<Coordinate> coordinates) {
        this.coordinates = coordinates;
        setSelfOnCoordinates();
    }

    public void setSize(double size) {
        this.size = size;
    }

    @Transient
    public void copyPropertiesOfElement(OverlayElement overlayElement) {
        setColor(overlayElement.getColor());
        dynamicallySetCoordinates(overlayElement.getCoordinates());
        setOpacity(overlayElement.getOpacity());
        setSize(overlayElement.getSize());
    }

    @Transient
    public void setSelfOnCoordinates() {
        for (Coordinate coordinate : coordinates) {
            coordinate.setOverlayElement(this);
        }
    }

    @Transient
    public void dynamicallySetCoordinates(List<Coordinate> coordinates) {
        int sizeA = this.coordinates.size(), sizeB = coordinates.size();
        for (int i = 0; i < sizeA || i < sizeB; i++) {
            if (i < sizeA && i < sizeB) {
                Coordinate oldCoordinate = this.coordinates.get(i);
                Coordinate newCoordinate = coordinates.get(i);
                oldCoordinate.setLat(newCoordinate.getLat());
                oldCoordinate.setLng(newCoordinate.getLng());
            } else if (i < sizeA) {
                this.coordinates.remove(i);
            } else {
                coordinates.get(i).setOverlayElement(this);
                this.coordinates.add(coordinates.get(i));
            }
        }
    }
}