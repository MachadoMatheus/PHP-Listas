package br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.controller;

import br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.dao.*;
import br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.entities.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Controller
@Transactional
public class MapController {
    private OverlayElementDAO overlayElementDAO;
    private CoordinateDAO coordinateDAO;

    @Autowired
    public MapController(OverlayElementDAO overlayElementDAO, CoordinateDAO coordinateDAO) {
        this.overlayElementDAO = overlayElementDAO;
        this.coordinateDAO = coordinateDAO;
    }

    @RequestMapping(value = {"/", "", "index"}, method = RequestMethod.GET)
    public ModelAndView index(@ModelAttribute("overlayElement") OverlayElement overlayElement) {
        return new ModelAndView("edit");
    }

    @RequestMapping(value = "register", method = RequestMethod.GET)
    public ModelAndView register(@ModelAttribute("overlayElement") OverlayElement overlayElement) {
        return new ModelAndView("register");
    }

    @RequestMapping(value = "register", method = RequestMethod.POST)
    public String addOverlayElement(@ModelAttribute("overlayElement") OverlayElement overlayElement) {
        for (int i = 0; i < overlayElement.getCoordinates().size(); i++) {
            overlayElement.getCoordinates().get(i).setPosition(i);
        }
        overlayElementDAO.save(overlayElement);
        return "redirect:index";
    }

    @ResponseBody
    @RequestMapping(value = "getOverlayElements", method = RequestMethod.GET, produces = APPLICATION_JSON_VALUE)
    public List<OverlayElement> getOverlayElements() {
        return overlayElementDAO.searchAllOverlayElements();
    }

    @ResponseBody
    @RequestMapping(value = "setOverlayElement", method = RequestMethod.POST, consumes = APPLICATION_JSON_VALUE)
    public void setOverlayElement(@RequestBody final OverlayElement overlayElementJSON) {
        OverlayElement overlayElement = overlayElementDAO.searchById(overlayElementJSON.getId());

        for (Coordinate coordinate : overlayElement.getCoordinates()) {
            coordinateDAO.delete(coordinate);
        }
        overlayElement.copyPropertiesOfElement(overlayElementJSON);

        overlayElementDAO.save(overlayElement);
    }

    @ResponseBody
    @RequestMapping(value = "deleteOverlayElement", method = RequestMethod.POST, consumes = APPLICATION_JSON_VALUE)
    public void removeOverlayElement(@RequestBody final OverlayElement overlayElementJSON) {
        OverlayElement overlayElement = overlayElementDAO.searchById(overlayElementJSON.getId());
        overlayElementDAO.remove(overlayElement);
    }
}