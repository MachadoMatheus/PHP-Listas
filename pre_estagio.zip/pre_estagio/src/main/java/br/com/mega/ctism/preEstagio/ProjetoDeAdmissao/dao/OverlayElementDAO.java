package br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.dao;
import br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.entities.OverlayElement;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Component
@Repository
@Transactional
public class OverlayElementDAO {
    private CriteriaBuilder criteriaBuilder;

    @PersistenceContext
    private EntityManager entityManager;

    @PostConstruct
    public void inicio() {
        criteriaBuilder = entityManager.getCriteriaBuilder();
    }

    public void save(OverlayElement overlayElement) {
        entityManager.persist(overlayElement);
    }

    public void remove(OverlayElement overlayElement) {
        entityManager.remove(overlayElement);
    }

    public OverlayElement searchById(Integer id) {
        CriteriaQuery<OverlayElement> query = criteriaBuilder.createQuery(OverlayElement.class);
        Root<OverlayElement> overlayElementRoot = query.from(OverlayElement.class);
        query.select(overlayElementRoot);
        query.where(criteriaBuilder.equal(overlayElementRoot.get("id"), id));

        OverlayElement overlayElement;
        try {
            overlayElement = entityManager.createQuery(query).getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
            overlayElement = null;
        }

        return overlayElement;
    }

    public List<OverlayElement> searchAllOverlayElements() {
        try {
            CriteriaQuery<OverlayElement> query = criteriaBuilder.createQuery(OverlayElement.class);
            Root<OverlayElement> overlayElementRoot = query.from(OverlayElement.class);
            query.select(overlayElementRoot);

            return entityManager.createQuery(query).getResultList();

        } catch (Exception ignored) {
            return new ArrayList<>();
        }
    }
}