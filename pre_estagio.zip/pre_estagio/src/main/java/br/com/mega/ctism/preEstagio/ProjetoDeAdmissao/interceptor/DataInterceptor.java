package br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.interceptor;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DataInterceptor extends HandlerInterceptorAdapter {

    @PersistenceContext(unitName = "entityManagerFactory")
    private EntityManager entityManager;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        try {
            entityManager.getTransaction().begin();
            return true;
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            entityManager.close();
            e.printStackTrace();
            return false;
        }
    }

    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        entityManager.getTransaction().commit();
        entityManager.close();
    }
}
