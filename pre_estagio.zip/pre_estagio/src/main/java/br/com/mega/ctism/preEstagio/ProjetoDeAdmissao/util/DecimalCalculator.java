package br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.util;

import java.math.BigDecimal;

public class DecimalCalculator {

    public double round(double val, int precision) {
        BigDecimal rounder = new BigDecimal(String.valueOf(val)).setScale(precision, BigDecimal.ROUND_HALF_EVEN);

        return rounder.doubleValue();
    }

    public double round(double val) {
        return round(val, 2);
    }

    public double remainder(double val1, double val2) {
        if (val2 == 0) {
            return 0;
        }
        BigDecimal val1Decimal = new BigDecimal(String.valueOf(val1));
        BigDecimal val2Decimal = new BigDecimal(String.valueOf(val2));

        return val1Decimal.remainder(val2Decimal).doubleValue();
    }

    public double subtraction(double val1, double val2) {
        BigDecimal val1Decimal = new BigDecimal(String.valueOf(val1));
        BigDecimal val2Decimal = new BigDecimal(String.valueOf(val2));

        return val1Decimal.subtract(val2Decimal).doubleValue();
    }

    public double sum(double val1, double val2) {
        BigDecimal val1Decimal = new BigDecimal(String.valueOf(val1));
        BigDecimal val2Decimal = new BigDecimal(String.valueOf(val2));

        return val1Decimal.add(val2Decimal).doubleValue();
    }
}
