package br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;

@Entity
@Table(name = "coordinate")
@JsonIgnoreProperties(value = {"overlayElement"})
public class Coordinate {
    private Integer id;
    private double lat, lng;
    private OverlayElement overlayElement;
    private int position;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "lat")
    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    @Basic
    @Column(name = "lng")
    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    @Basic
    @Column(name = "position")
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }


    @ManyToOne(fetch = FetchType.EAGER)
    public OverlayElement getOverlayElement() {
        return overlayElement;
    }

    public void setOverlayElement(OverlayElement overlayElement) {
        this.overlayElement = overlayElement;
    }
}