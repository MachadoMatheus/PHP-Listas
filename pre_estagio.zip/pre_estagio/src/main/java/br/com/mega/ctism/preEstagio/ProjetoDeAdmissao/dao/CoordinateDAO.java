package br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.dao;

import br.com.mega.ctism.preEstagio.ProjetoDeAdmissao.entities.Coordinate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Component
@Repository
@Transactional
public class CoordinateDAO {
    private CriteriaBuilder criteriaBuilder;

    @PersistenceContext
    private EntityManager entityManager;

    @PostConstruct
    public void inicio() {
        criteriaBuilder = entityManager.getCriteriaBuilder();
    }

    public void save(Coordinate coordinate) {
        entityManager.persist(coordinate);
    }


    public void delete(Coordinate coordinate) {
        entityManager.remove(coordinate);
    }

    public Coordinate searchById(Integer id) {
        CriteriaQuery<Coordinate> query = criteriaBuilder.createQuery(Coordinate.class);
        Root<Coordinate> coordinateRoot = query.from(Coordinate.class);
        query.select(coordinateRoot);
        query.where(criteriaBuilder.equal(coordinateRoot.get("id"), id));

        Coordinate coordinate;
        try {
            coordinate = entityManager.createQuery(query).getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
            coordinate = null;
        }

        return coordinate;
    }

    public List<Coordinate> searchAllCoordinates() {
        try {
            CriteriaQuery<Coordinate> query = criteriaBuilder.createQuery(Coordinate.class);
            Root<Coordinate> coordinateRoot = query.from(Coordinate.class);
            query.select(coordinateRoot);

            return entityManager.createQuery(query).getResultList();

        } catch (Exception ignored) {
            return new ArrayList<>();
        }
    }
}
